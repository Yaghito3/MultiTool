import requests
import time

url = "https://soccertime.uk/Home/Aggiorna?dato="
TEST = input("NOI, CREATORI DI QUESTO TOOL, NON CI ASSUMIAMO RESPONSABILITA' DI COME QUESTO TOOL VIENE USATO. CONFERMI CHE LO USERAI A SCOPI LECITI??    Y/N ------> ")
if TEST != "Y":
    print("ci dispiace, non puoi proseguire.")
    time.sleep(1)
    exit()


def botothersite():
    
    try:
        response = requests.get(text2+text)
        print("Richiesta inviata a:", text2+text)
        response.raise_for_status()
        print("Risposta:", response.text) 
    except requests.RequestException as e:
        print("Errore:", e)

text2 = input("qual'è l'url per le richieste del sito desiderato? (senza dati alla fine) --->  ")
text = input("che cosa vuoi far comparire nel sito? --->  ")
while True:
    botothersite()
    




